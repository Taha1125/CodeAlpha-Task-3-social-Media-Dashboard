# Task-3-Socail-Media-DashBoard-CodeAlpha-
task 3 internship of code aplha . 
I create a website for social media dashboard of one profile with the help of html css and java script.
